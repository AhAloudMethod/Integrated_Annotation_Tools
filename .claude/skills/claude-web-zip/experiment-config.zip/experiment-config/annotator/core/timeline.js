// タイムライン（シーク＋グラフ直接編集）と画面の再描画（refresh）
(() => {
  const _ = AH._;
  const { FPS, $, video, tl, tctx, S, model, isInt, wall, r2, clamp, addLog, snapshot, pushUndo, css, fmt, RG, nSec, binStart, rangeEnd, binAt, inRange, valueIn, endStroke, writeMode } = _;
  // ---------- タイムライン（シーク＋直接編集） ----------
  const PAD_L = 44, PAD_R = 8, RULER = 28;   // 下端 RULER px はシーク用の目盛り帯（狭いとグラフの編集と押し間違えるので広めにとる）
  // 表示している時間の範囲（Ctrl+ホイールで拡大・縮小、Shift+ホイールと横スワイプで横にスクロール）。null は動画全体
  let view = null;
  const MIN_SPAN = 1;   // 拡大の上限：表示の幅（秒）
  const viewNow = () => (view && S.meta.duration ? view : { t0: 0, t1: S.meta.duration || 0 });
  function geom() {
    const w = tl.clientWidth, h = tl.clientHeight, D = S.meta.duration, { t0, t1 } = viewNow(), span = t1 - t0 || 1;
    const xOf = t => PAD_L + (D ? (t - t0) / span : 0) * (w - PAD_L - PAD_R);
    const tOf = x => D ? t0 + clamp((x - PAD_L) / (w - PAD_L - PAD_R), 0, 1) * span : 0;
    // F0 を表示するときは、下に F0 の欄（FH px）を足す
    const FH = _.f0Shown && _.f0Shown() && video.src ? 56 : 0, H2 = h - RULER - FH;
    const lanes = [{ ax: 'v', name: _.ax('v').short, col: css('--axv'), y0: 8, y1: H2 / 2 - 8 },
                   { ax: 'a', name: _.ax('a').short, col: css('--axa'), y0: H2 / 2 + 8, y1: H2 - 8 }];
    const f0Lane = FH ? { y0: H2 + 8, y1: h - RULER - 4, top: H2 } : null;
    for (const L of lanes) {
      L.lo = 1; L.hi = 9;
      const gs = _.M && _.M.graphScale && _.M.graphScale();   // 方式が評価グラフの軸を決めるとき（PANAS の合計：lo・hi・中央 mid・欄の名前に足す語 tag）
      if (gs) { L.lo = gs.lo; L.hi = gs.hi; L.mid = gs.mid; L.tag = gs.tag || ''; } else { L.mid = 5; L.tag = ''; }
      if (_.M && _.M.unbounded && S.data) { const vs = S.data.points[L.ax].map(p => p.val); L.lo = Math.min(...vs) - 1; L.hi = Math.max(...vs) + 1; }
      L.yOf = v => L.y1 - (v - L.lo) / (L.hi - L.lo) * (L.y1 - L.y0);
      L.vOf = y => L.lo + (L.y1 - y) / (L.y1 - L.y0) * (L.hi - L.lo);
    }
    return { w, h, D, t0, t1, xOf, tOf, lanes, f0Lane };
  }
  // 線や塗りをグラフの領域（左の軸の名前と右の余白を除く）に収める。g.restore() で戻す
  const clipPlot = (g, G) => { g.save(); g.beginPath(); g.rect(PAD_L - 1, 0, G.w - PAD_L - PAD_R + 2, G.h); g.clip(); };
  // 目盛りの間隔（秒）：隣の目盛りと 60 px 以上離れる最小の間隔
  const TICKS = [0.1, 0.2, 0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600];
  const tickStep = G => { const pps = (G.w - PAD_L - PAD_R) / (G.t1 - G.t0 || 1); return TICKS.find(s => s * pps >= 60) || TICKS[TICKS.length - 1]; };

  function drawTimeline() {
    const g = tctx, G = geom(), { w, h, D, xOf } = G;
    g.clearRect(0, 0, w, h);
    g.font = '11px system-ui, sans-serif';
    if (D) {
      clipPlot(g, G);
      // 評価区間の外を薄く塗る
      g.fillStyle = css('--grid'); g.globalAlpha = 0.6;
      if (RG().start > 0) g.fillRect(xOf(0), 0, xOf(Math.min(RG().start, D)) - xOf(0), h - RULER);
      if (rangeEnd() < D) g.fillRect(xOf(rangeEnd()), 0, xOf(D) - xOf(rangeEnd()), h - RULER);
      g.globalAlpha = 1;
      // 発声の区間（core/voiced.js）：声のある所を快度・覚醒度の欄に薄い色で塗る
      if (_.voicedShown()) {
        const lanes0 = geom().lanes; g.fillStyle = css('--f0'); g.globalAlpha = 0.13;
        for (const [t0, t1] of _.voicedSpans()) for (const L of lanes0) g.fillRect(xOf(t0), L.y0, Math.max(1, xOf(Math.min(t1, D)) - xOf(t0)), L.y1 - L.y0);
        g.globalAlpha = 1;
      }
      // 区間の境界（評価区間に合わせた格子）と動画時刻の目盛り。自分で置いた区切り（不揃いの区間）は濃く引く
      const own = !!RG().edges;
      for (let s = 0; s <= nSec(); s++) {
        const bs = s === nSec() ? rangeEnd() : binStart(s), x = xOf(bs); if (bs > D + 1e-6) break;
        g.strokeStyle = own ? css('--muted') : css('--line'); g.lineWidth = own ? 1.5 : s % 5 === 0 ? 1.4 : 0.8;
        g.beginPath(); g.moveTo(x, 4); g.lineTo(x, h - RULER); g.stroke();
      }
      // 区間内で変化：パネルのボタンの対象の区間を点線の枠で示す
      const ts = _.curveOn() && _.M.curveTarget ? _.M.curveTarget() : -1;
      if (ts >= 0 && ts < nSec()) {
        const x0 = xOf(binStart(ts)), x1 = xOf(Math.min(_.binEnd(ts), D));
        g.strokeStyle = css('--ink'); g.lineWidth = 2; g.setLineDash([5, 3]); g.strokeRect(x0 + 1, 3, Math.max(2, x1 - x0 - 2), h - RULER - 5); g.setLineDash([]);
      }
      g.fillStyle = css('--bg'); g.fillRect(PAD_L, h - RULER, w - PAD_L - PAD_R, RULER);
      g.fillStyle = css('--muted');
      const step = tickStep(G), dec = step < 1 ? 1 : 0;
      for (let k = Math.ceil(G.t0 / step - 1e-9); k * step <= G.t1 + 1e-9; k++) g.fillText((k * step).toFixed(dec) + 's', xOf(k * step) + 2, h - 9);
      // 拡大しているときは倍率を目盛りの帯の右端に出す
      if (G.t1 - G.t0 < D - 1e-6) {
        const s = '×' + (D / (G.t1 - G.t0)).toFixed(1), tw = g.measureText(s).width;
        g.fillStyle = css('--bg'); g.fillRect(w - PAD_R - tw - 8, h - RULER + 4, tw + 8, RULER - 6);
        g.fillStyle = css('--ink'); g.fillText(s, w - PAD_R - tw - 4, h - 9);
      }
      g.restore();
    }
    // 快度と覚醒度の欄の区切り線
    const yDiv = Math.round((G.lanes[0].y1 + G.lanes[1].y0) / 2) + 0.5;
    g.strokeStyle = css('--pen'); g.lineWidth = 1.5;   // 赤
    g.beginPath(); g.moveTo(0, yDiv); g.lineTo(w, yDiv); g.stroke();
    for (const L of G.lanes) {
      g.fillStyle = css('--muted'); g.fillText(L.name + L.tag, 2, L.y0 + 10);
      if (!(_.M && _.M.unbounded)) {
        g.fillText(String(L.mid), PAD_L - (L.mid > 9 ? 18 : 12), L.yOf(L.mid) + 4);
        g.strokeStyle = css('--line'); g.lineWidth = 1;   // 中立（5）の線は実線
        g.beginPath(); g.moveTo(PAD_L, L.yOf(L.mid)); g.lineTo(w - PAD_R, L.yOf(L.mid)); g.stroke();
      }
      if (!D || !S.data) continue;
      clipPlot(g, G);
      g.strokeStyle = L.col; g.fillStyle = L.col; g.lineWidth = 2;
      if (model() === 'series') {
        const ps = S.data.points[L.ax];
        g.beginPath();
        ps.forEach((p, i) => {
          const y = L.yOf(p.val);
          if (i === 0) g.moveTo(xOf(p.t), y); else g.lineTo(xOf(p.t), y);
          const nx = i + 1 < ps.length ? xOf(ps[i + 1].t) : xOf(D);
          g.lineTo(nx, y); if (i + 1 < ps.length) g.lineTo(nx, L.yOf(ps[i + 1].val));
        });
        g.stroke();
        if (isInt() && ps.length < 400) for (const p of ps) if (!p.init) { g.beginPath(); g.arc(xOf(p.t), L.yOf(p.val), 2.5, 0, 7); g.fill(); }
      } else if (model() === 'table') {
        const c = S.data.cells[L.ax];
        for (let s = 0; s < nSec(); s++) {
          const cv = _.M.graphCell ? _.M.graphCell(L.ax, s) : c[s];   // 方式が区間の値を別に持つとき（PANAS の合計）
          if (cv == null) continue;
          if (_.curveIsCurve(L.ax, s)) { drawCurveSec(g, L, s, xOf, D); continue; }   // 変化の区間（core/curve.js）は系列の線
          const x0 = xOf(binStart(s)) + 1, bw = xOf(Math.min(_.binEnd(s), D)) - xOf(binStart(s)) - 2;
          if (cv === 0) {   // 0 は発声なし：値の線ではなく、欄の高さの灰色の帯にする
            g.fillStyle = css('--muted'); g.globalAlpha = 0.25; g.fillRect(x0, L.y0, bw, L.y1 - L.y0); g.globalAlpha = 1; g.fillStyle = L.col;
          } else g.fillRect(x0, L.yOf(cv) - 1.5, bw, 3);
        }
      } else if (model() === 'events') {
        const mid = (L.y0 + L.y1) / 2;
        for (const e of S.data.events) {
          if (!e.dv && !e.da) { g.fillRect(xOf(e.t) - 1, L.y0 + 2, 2, L.y1 - L.y0 - 4); continue; }   // 方向のない変化（変化ボタン）は縦線
          const d = L.ax === 'v' ? e.dv : e.da; if (!d) continue;
          const x = xOf(e.t), y = mid - d * 10;
          g.beginPath(); g.moveTo(x, y - d * 6); g.lineTo(x - 5, y + d * 2); g.lineTo(x + 5, y + d * 2); g.closePath(); g.fill();
        }
      }
      g.restore();
    }
    if (D && G.f0Lane) drawF0(g, G);
    if (D) {
      clipPlot(g, G);
      if (_.stroke) {
        g.fillStyle = css('--pen'); g.globalAlpha = 0.15;
        g.fillRect(xOf(_.stroke.t0), 2, Math.max(1, xOf(_.stroke.lastT) - xOf(_.stroke.t0)), h - RULER - 2); g.globalAlpha = 1;
      }
      const x = xOf(_.seekTarget());   // シークの途中は向かっている位置（core/video.js）
      g.strokeStyle = _.stroke ? css('--pen') : css('--head'); g.lineWidth = 1.5;
      g.beginPath(); g.moveTo(x, 2); g.lineTo(x, h); g.stroke();
      g.restore();
    }
  }

  // 区間内で変化（core/curve.js）の変化の区間：系列の線を区間の中だけ描く。0（発声なし）の所は欄の高さの灰色の帯にする
  function drawCurveSec(g, L, s, xOf, D) {
    const ps = S.data.points[L.ax], b0 = binStart(s), b1 = Math.min(_.binEnd(s), D), segs = [];
    let t = b0, v = valueIn(ps, b0);
    for (const p of ps) if (p.t > b0 + 1e-4 && p.t < b1 - 1e-6) { segs.push([t, p.t, v]); t = p.t; v = p.val; }
    segs.push([t, b1, v]);
    g.beginPath(); let on = false;
    for (const [t0, t1, val] of segs) {
      if (val === 0) { g.save(); g.fillStyle = css('--muted'); g.globalAlpha = 0.25; g.fillRect(xOf(t0), L.y0, xOf(t1) - xOf(t0), L.y1 - L.y0); g.restore(); on = false; continue; }
      const y = L.yOf(val);
      if (!on) { g.moveTo(xOf(t0), y); on = true; } else g.lineTo(xOf(t0), y);
      g.lineTo(xOf(t1), y);
    }
    g.stroke();
  }

  // F0 の欄：声ありの区間を線でつなぐ（縦軸は対数。範囲はその動画の F0 の分布から）
  function drawF0(g, G) {
    const { w, xOf, f0Lane: L } = G, F = _.F0;
    g.strokeStyle = css('--line'); g.lineWidth = 1;
    g.beginPath(); g.moveTo(0, Math.round(L.top) + 0.5); g.lineTo(w, Math.round(L.top) + 0.5); g.stroke();
    g.fillStyle = css('--muted'); g.fillText('F0', 2, L.y0 + 10);
    if (F.status !== 'ready') { g.fillText(F.status === 'loading' ? '計算中…' : F.status === 'error' ? '読み込めませんでした' : '', PAD_L + 6, L.y0 + 22); return; }
    const lo = Math.log(F.lo), span = Math.log(F.hi) - lo, yOf = f => L.y1 - (Math.log(f) - lo) / span * (L.y1 - L.y0);
    g.font = '10px system-ui, sans-serif';
    g.fillText(Math.round(F.hi) + 'Hz', 2, L.y0 + 22); g.fillText(Math.round(F.lo), 2, L.y1);
    g.font = '11px system-ui, sans-serif';
    clipPlot(g, G);
    g.strokeStyle = css('--f0'); g.lineWidth = 1.5; g.beginPath();
    let pen = false; const off = 0.02;   // 窓の中心の時刻
    for (let k = 0; k < F.f0.length; k++) {
      const f = F.f0[k];
      if (!(f > 0)) { pen = false; continue; }
      const x = xOf(k * F.hop + off), y = Math.max(L.y0, Math.min(L.y1, yOf(f)));
      if (pen) g.lineTo(x, y); else { g.moveTo(x, y); pen = true; }
    }
    g.stroke();
    const now = _.f0At(video.currentTime || 0);
    if (now > 0) { g.fillStyle = css('--f0'); g.beginPath(); g.arc(xOf(video.currentTime), Math.max(L.y0, Math.min(L.y1, yOf(now))), 3.5, 0, 7); g.fill(); }
    g.restore();
  }

  // グラフ直接編集：連続方式はなぞった範囲の値を描き換え、区間方式は区間の値を設定する
  let edit = null, seeking = false;
  // 区間内で変化（core/curve.js）はグラフだけで入れるので、設定に関わらずいつも編集できる
  const graphEditable = () => ($('graphEdit').checked || _.curveOn()) && model() !== 'events' && !(_.M && _.M.derivedCells) && !!video.src && !_.reviewing();   // derivedCells：区間の値を回答から作る方式（PANAS）は、グラフで値を置けない（押すとシークになる）
  // なぞった範囲の値を描き換え、その直後は編集前の値に戻す（core/series.js の rewriteFrames）。
  // フレームが続いている所ごとに描き換える（区間内で変化では、変化の区間のフレームだけを描くので、間が空くことがある）
  function editRebuild() {
    let ps = edit.before.points[edit.axis], run = new Map(), prev = null;
    for (const f of [...edit.samples.keys()].sort((a, b) => a - b)) {
      if (prev != null && f !== prev + 1) { ps = _.rewriteFrames(ps, run); run = new Map(); }
      run.set(f, edit.samples.get(f)); prev = f;
    }
    if (run.size) ps = _.rewriteFrames(ps, run);
    S.data.points[edit.axis] = ps;
  }
  function editAt(ev) {
    const r = tl.getBoundingClientRect(), G = geom(), L = G.lanes.find(l => l.ax === edit.axis);
    const t = G.tOf(ev.clientX - r.left);
    let v = L.vOf(clamp(ev.clientY - r.top, L.y0, L.y1));
    if (!(_.M && _.M.unbounded)) v = clamp(v, 1, 9);
    v = edit.series && model() === 'table' ? r2(v) : isInt() ? Math.round(v) : _.M && _.M.decimals === 1 ? Math.round(v * 10) / 10 : r2(v);   // Excel の連続値は小数第1位まで（変化の区間は連続の方式と同じ）
    if (!edit.series) {
      const s = binAt(t); if (s < 0 || s >= nSec() || _.curveIsCurve(edit.axis, s) || _.novoiceLocked(s)) return;   // 変化の区間のセルは、セルの値で上書きしない
      if (S.data.cells[edit.axis][s] !== v) { if (!edit.changed) pushUndo(edit.before); edit.changed = true; S.data.cells[edit.axis][s] = v; edit.bins.add(s); }
    } else {
      const f = Math.round(t * FPS), q = x => (isInt() && model() === 'series' ? Math.round(x) : r2(x));
      const ok = ff => model() === 'series' || _.curveSeriesAt(edit.axis, ff / FPS + 1e-4);   // 区間内で変化：変化の区間のフレームだけ描く
      if (edit.lastF != null) { const d = f - edit.lastF, v0 = edit.lastV; for (let k = 1; k < Math.abs(d); k++) { const ff = edit.lastF + Math.sign(d) * k, vv = v0 + (v - v0) * k / Math.abs(d); if (ok(ff)) edit.samples.set(ff, q(vv)); } }
      if (ok(f)) edit.samples.set(f, v);
      edit.lastF = f; edit.lastV = v;
      if (!edit.samples.size) return;
      edit.changed = true;
      editRebuild();
    }
    refresh();
  }
  // 右クリック（連続評価と Excel）：区切りから離れた所で置く、区切りの上で動かさずに離すと消す、右ドラッグで動かす。
  // 1回の操作を取り消し（Ctrl+Z）の1件にする。左クリックはグラフ編集・シークのまま
  let cut = null;
  const CUT_HIT = 6;   // 区切りの線に乗ったとみなす距離（px）
  // 実験モードでは評価区間を変えさせない。ただしカスタムの Excel で「自分で区切る」を選んだ試行は参加者が区切る
  const selfCuts = () => !!(_.M && _.M.selfCuts && _.M.selfCuts());
  const cutsEditable = () => (model() === 'series' || !!(_.M && _.M.graphCuts)) && !!video.src && !_.reviewing() && (!(_.expOn && _.expOn()) || selfCuts());
  const frameT = t => { const f = (_.fps && _.fps()) || FPS; return +(Math.round(t * f) / f).toFixed(4); };   // いちばん近いフレームの始まり
  function cutHit(x) {
    const G = geom(), e = _.cutEdges(); let hit = -1, best = CUT_HIT;
    for (let i = 1; i < e.length - 1; i++) { const d = Math.abs(G.xOf(e[i]) - x); if (d <= best) { best = d; hit = i; } }
    return hit;
  }
  tl.addEventListener('contextmenu', e => { if (cutsEditable()) e.preventDefault(); });
  tl.addEventListener('pointerdown', e => {
    if (!S.meta.duration) return;
    const r = tl.getBoundingClientRect(), y = e.clientY - r.top;
    if (e.button === 2) {   // 右クリックはグラフ編集・シークに使わない
      if (!cutsEditable()) return;
      tl.setPointerCapture(e.pointerId);
      const x = e.clientX - r.left, i = cutHit(x);
      cut = { i, x0: x, x, moved: false, before: _.undoPoint(), t0: i > 0 ? _.cutEdges()[i] : null };
      return;
    }
    tl.setPointerCapture(e.pointerId);
    const Gd = geom();
    if (y >= r.height - RULER || !graphEditable() || (Gd.f0Lane && y >= Gd.f0Lane.top)) { seeking = true; _.seekTo(geom().tOf(e.clientX - r.left)); return; }
    endStroke('graph');
    const G = geom(), axis = y < (G.lanes[0].y1 + G.lanes[1].y0) / 2 ? 'v' : 'a';
    // 区間内で変化のテンプレート（core/curve.js）：押した区間に、押した高さから離した高さへの曲線を入れる
    const LA = G.lanes.find(l => l.ax === axis);
    const tP = G.tOf(e.clientX - r.left);
    if (_.curveOn() && _.M.curveSelect) { const s = binAt(tP); if (s >= 0 && s < nSec()) _.M.curveSelect(s); }   // 押した区間をパネルのボタンの対象にする
    if (_.curveDown(axis, tP, LA.vOf(clamp(y, LA.y0, LA.y1)))) return;
    // series：系列を描く（連続の方式と、区間内で変化で変化の区間を押したとき）。それ以外の区間方式はセルの値を置く
    edit = { axis, before: snapshot(), samples: new Map(), lastF: null, lastV: null, changed: false, bins: new Set(), series: model() === 'series' || _.curveSeriesAt(axis, tP) };
    editAt(e);
  });
  tl.addEventListener('pointermove', e => {
    if (cut) {
      cut.x = e.clientX - tl.getBoundingClientRect().left;
      if (cut.i > 0 && (cut.moved || Math.abs(cut.x - cut.x0) > 3)) { cut.moved = true; _.moveCut(cut.i, frameT(geom().tOf(cut.x)), true); }
      return;
    }
    if (_.curveDragging()) { const r = tl.getBoundingClientRect(), L = geom().lanes.find(l => l.ax === _.curveDragging()); _.curveMove(L.vOf(clamp(e.clientY - r.top, L.y0, L.y1))); return; }
    if (seeking) { const r = tl.getBoundingClientRect(); _.seekTo(geom().tOf(e.clientX - r.left)); }
    else if (edit) editAt(e);
    else if (S.meta.duration) {
      const r = tl.getBoundingClientRect();
      tl.style.cursor = cutsEditable() && cutHit(e.clientX - r.left) > 0 ? 'col-resize'
        : (e.clientY - r.top >= r.height - RULER || !graphEditable()) ? 'pointer' : 'crosshair';
    }
  });
  function cutUp() {
    const c = cut; cut = null;
    if (c.i < 0) _.addCut(frameT(geom().tOf(c.x0)));
    else if (!c.moved) _.delCut(c.t0);
    else {
      const t = _.moveCut(c.i, frameT(geom().tOf(c.x)));
      if (t !== c.t0) { pushUndo(c.before); addLog('range_cut', { value: 'move', detail: `t=${c.t0}->${t}` }); }
    }
  }
  const tlUp = () => {
    if (cut) { cutUp(); return; }
    if (_.curveDragging()) { _.curveUp(); return; }
    seeking = false;
    if (!edit) return;
    const e = edit; edit = null;
    if (e.changed) {
      if (e.series) {
        pushUndo(e.before);
        const fs = [...e.samples.keys()].sort((a, b) => a - b);
        S.data.strokes.push({ id: S.data.strokes.length, source: 'graph', axes: e.axis, t_start: fs[0] / FPS, t_end: fs[fs.length - 1] / FPS, end_reason: 'graph', wall_ms_end: wall(),
          samples: fs.map(f => [+(f / FPS).toFixed(4), e.axis === 'v' ? e.samples.get(f) : '', e.axis === 'a' ? e.samples.get(f) : '']) });
        addLog('graph_draw', { axis: e.axis, detail: `${(fs[0] / FPS).toFixed(3)}-${(fs[fs.length - 1] / FPS).toFixed(3)}` });
        _.curveTrim(e.axis, fs[0] / FPS, (fs[fs.length - 1] + 1) / FPS);   // 描き直した範囲は形の記録から外す（区間内で変化）
      } else addLog('graph_cells', { axis: e.axis, detail: 'bins ' + [...e.bins].sort((a, b) => a - b).join(' ') });
    }
    refresh();
  };
  tl.addEventListener('pointerup', tlUp); tl.addEventListener('pointercancel', tlUp);

  // 時間軸のズーム：Ctrl（Mac は ⌘ も）+ホイールでカーソル位置の時刻を固定して拡大・縮小する（トラックパッドのピンチも Ctrl+ホイールで届く）。
  // Shift+ホイールと横スワイプは拡大中だけ横にスクロールする。修飾キーなしの縦のホイールには何もしない
  function setView(t0, span) {
    const D = S.meta.duration;
    span = clamp(span, Math.min(MIN_SPAN, D), D);
    t0 = clamp(t0, 0, D - span);
    view = span >= D - 1e-9 ? null : { t0, t1: t0 + span };
    drawTimeline();
  }
  tl.addEventListener('wheel', e => {
    const D = S.meta.duration; if (!D) return;
    const px = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? tl.clientWidth : 1;   // 行・ページ単位のホイールを px にそろえる
    const G = geom(), span = G.t1 - G.t0;
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();   // ブラウザのページの拡大を止める
      const dy = e.deltaY * px, k = Math.exp(dy * (Math.abs(dy) < 50 ? 0.01 : 0.002));   // 小さい値はピンチなので強めに効かせる
      const r = tl.getBoundingClientRect(), tc = G.tOf(e.clientX - r.left), ns = clamp(span * k, Math.min(MIN_SPAN, D), D);
      setView(tc - (tc - G.t0) * ns / span, ns);
      return;
    }
    const d = (e.shiftKey ? e.deltaX || e.deltaY : Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : 0) * px;
    if (!d || !view) return;
    e.preventDefault();
    setView(G.t0 + d * span / (G.w - PAD_L - PAD_R), span);
  }, { passive: false });
  const tlView = () => ({ ...viewNow() });
  const tlViewReset = () => { view = null; };

  function refresh() {
    _.applyNoVoice();   // 発声なしの事前設定の区間を 0 にそろえる（core/table.js）
    const t = video.currentTime || 0;
    if (_.renderF0) _.renderF0();
    // 区間外は時刻の右上の札にする（文字に足すと幅が変わり、右のボタンがずれる）
    const ct = _.seekTarget ? _.seekTarget() : t;
    $('clock').textContent = fmt(ct) + ' / ' + fmt(S.meta.duration);
    $('clock').dataset.out = S.meta.duration && !inRange(ct) ? '区間外' : '';
    $('playBtn').textContent = video.paused ? '再生' : '停止';
    $('playBtn').dataset.rate = video.playbackRate !== 1 ? '×' + video.playbackRate : '';   // 1 以外の再生速度はボタンの角に出す
    $('armBox').hidden = writeMode() !== 'armed' || _.listenUsable();
    _.listenStatus();
    if (!$('rgPanel').hidden) _.frameSync();
    $('armBtn').textContent = S.armed ? '● 記録オン' : '記録オフ R';
    $('armBtn').classList.toggle('on', S.armed);
    if (_.M && S.data) {
      $('status').textContent = video.src ? (_.stroke ? '書き込み中' : '') : '練習中';
      if (_.M.update) _.M.update(t);
    }
    drawTimeline();
  }

  // C キー（core/keys.js と Excel のセル）：今表示しているフレームの始まりで区切る。右クリックで区切れるときだけ効く
  const cutNow = () => { if (!cutsEditable()) return false; _.addCut(_.frameStart ? _.frameStart(video.currentTime) : video.currentTime); return true; };

  Object.assign(_, { refresh, cutNow, tlView, tlViewReset });
})();
