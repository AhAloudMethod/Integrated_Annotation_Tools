// 実験モード：参加者内で方式を比べる実験に使う。実験者は experiment.json（試行の順）・setup.json（設定と動画ごとの評価区間）と動画を入れたフォルダを選び、参加者を選ぶ。
// 試行（方式×動画）を設定ファイルの順に進め、参加者が選べる要素（ID・方式・設定・評価区間など）を隠す。
// 各試行は ready（覆いに「開始」）→ running（評価する）→ done（完了で書き出し、入力をロック）と進む。
// 録画の試行（record: true）は、その前に pick（実験者が録画を選ぶ）→ align（実験者が評価区間の開始・終了を合わせる）を通る。
// タスク遂行時間は「開始」から「完了」まで。操作ログに task_start・task_end を残し、内訳（再生時間・シークの回数など）を要約にする。
// 書き出しは 1 試行 1 つの zip（その時点までの要約も入れる）。zip はブラウザ（IndexedDB）にも残し、参加者を選ぶ画面から書き出し直せる。
// 終えた試行は、実験者が選び直してやり直せる（前の評価を zip から戻して直すか、空から評価し直す）。やり直した回の zip には _redo1 などを付ける。
// 当てた設定はブラウザに保存されるので、実験モードを抜けるとき（とページを閉じるとき）に元の値へ戻す。Ctrl+Shift+E で抜ける（試行の途中なら _partial の zip を書き出す）。
// setup.json は通常の画面の「実験用設定を書き出す」で作る（設定の欄と、フォルダの動画ごとに覚えてある評価区間）
(() => {
  const _ = AH._;
  const { $, video, S, modes, addLog, endStroke, setArmed, pen } = _;
  // 設定の項目・既定値（書いていない項目はこれ。参加者のブラウザに残った値は使わない）と検査は core/exp-check.js
  const E = _.expCheck, { DEF } = E;
  const LS_KEYS = ['ahann_axes', 'ahann_after', 'ahann_grid', 'ahann_pad_square', 'ahann_f0', 'ahann_voiced', 'ahann_listen', 'ahann_tl', 'ahann_vidsize', 'ahann_pad_joy', 'ahann_pad_slider'];
  const SUM_COLS = ['trial', 'practice', 'mode', 'condition', 'video', 'start_iso', 'end_iso', 'task_ms', 'play_ms', 'review_ms', 'n_play', 'n_seek', 'n_undo', 'n_redo',
    'n_strokes', 'n_events', 'bins', 'filled_v', 'filled_a', 'n_restore', 'partial', 'survey_opened', 'redo', 'prev_end_iso', 'task_ms_prev'];
  const isObj = x => !!x && typeof x === 'object' && !Array.isArray(x);
  const VIDEO_RE = /\.(mp4|m4v|mov|webm|mkv|avi|ogv|mpe?g|wmv)$/i;
  // X：実験の状態。cfg（experiment.json に setup.json を合わせたもの）、get（相対パス→File）、res（検査の結果）、pid、trials、i（今の試行）、set（今の設定）、range、state、backup（元の設定）、
  // redo（終えた試行をやり直すときの { n, prev_end_iso, task_ms_prev, from, session }。試行の動画を開いたときに当てる）
  let X = null;

  // ---------- フォルダの読み込みと検査 ----------
  // 選んだフォルダの中の experiment.json（いちばん浅いもの）を探す。setup.json と動画のパスはそのフォルダからの相対で引く。
  // list は File（webkitRelativePath つき）か、落としたフォルダから読んだ { file, path }（path は「フォルダ名/…」）の配列
  function readFolder(list) {
    const files = new Map(); let base = null, depth = Infinity;
    for (const it of list) {
      const f = it.file || it, full = it.file ? it.path : f.webkitRelativePath || f.name;
      const rel = full.split('/').slice(1).join('/') || f.name;
      files.set(rel, f);
      const d = rel.split('/').length;
      if (f.name === 'experiment.json' && d < depth) { depth = d; base = rel.slice(0, -'experiment.json'.length); }
    }
    const at = base ?? '';
    const get = p => files.get(at + String(p).replace(/^\.\//, '').replace(/\\/g, '/'));
    // 動画の一覧（experiment.json のあるフォルダから下）
    const videos = [...files.entries()].filter(([rel, f]) => rel.startsWith(at) && VIDEO_RE.test(f.name)).map(([rel, f]) => ({ path: rel.slice(at.length), file: f }))
      .sort((a, b) => a.path.localeCompare(b.path));
    return { cfgFile: base == null ? null : get('experiment.json'), setupFile: get('setup.json') || null, get, videos };
  }
  const readJSON = async f => JSON.parse((await f.text()).replace(/^﻿/, ''));   // 書き出したファイルは BOM で始まる
  const env = get => ({ modes: Object.keys(modes), axes: Object.keys(_.AXES), has: p => !!get(p) });

  // ---------- 結果の zip をブラウザ（IndexedDB）に残す ----------
  // キーは「実験名|参加者|試行の番号」（やり直した回は |redo1 など、途中で抜けたものは末尾に |partial）。値は { name, blob, exp, pid, trial, time }
  function idb() {
    return new Promise((ok, ng) => {
      const r = indexedDB.open('ahann_exp', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('zips');
      r.onsuccess = () => ok(r.result); r.onerror = () => ng(r.error);
    });
  }
  async function idbDo(mode, fn) {
    const db = await idb();
    try {
      return await new Promise((ok, ng) => {
        const tx = db.transaction('zips', mode), st = tx.objectStore('zips'), res = fn(st);
        tx.oncomplete = () => ok(res && 'result' in res ? res.result : undefined); tx.onerror = () => ng(tx.error);
      });
    } finally { db.close(); }
  }
  const zipPut = (key, v) => idbDo('readwrite', st => st.put(v, key));
  const zipAll = () => idbDo('readonly', st => st.getAll());
  // 試行の完了した zip のうち、いちばん新しいもの（やり直した回を含む。途中で抜けたものは除く）。無いか読めなければ null
  async function lastZip(pid, k) {
    try { return (await zipAll()).filter(z => z.exp === X.cfg.name && z.pid === pid && z.trial === k && !/_partial\.zip$/.test(z.name)).sort((a, b) => b.time - a.time)[0] || null; } catch (_e) { return null; }
  }
  const zipDel = async (exp, pid) => {
    const keys = await idbDo('readonly', st => st.getAllKeys());
    await idbDo('readwrite', st => { for (const k of keys) if (k.startsWith(`${exp}|${pid}|`)) st.delete(k); });
  };
  function downloadBlob(name, blob) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }

  // ---------- 進行（終えた試行と要約、録画の試行で選んだ録画と区間）はブラウザに残す ----------
  // { done: { 試行の番号: 要約 }, rec: { 試行の番号: { file, size, duration, start, end } } }
  const progKey = pid => `ahann_exp:${X.cfg.name}:${pid}`;
  function loadProg(pid) {
    try { return JSON.parse(localStorage.getItem(progKey(pid)) || '{}'); } catch (_e) { return {}; }
  }
  const writeProg = prog => { try { localStorage.setItem(progKey(X.pid), JSON.stringify(prog)); } catch (_e) {} };
  const loadProgress = pid => loadProg(pid).done || {};
  function saveProgress(i, row) {
    const prog = loadProg(X.pid), done = prog.done || {}; done[i] = { ...(done[i] || {}), ...row };
    writeProg({ ...prog, done });
  }
  const loadRec = i => (loadProg(X.pid).rec || {})[i] || null;
  function saveRec(i, rec) {
    const prog = loadProg(X.pid);
    writeProg({ ...prog, rec: { ...(prog.rec || {}), [i]: rec } });
  }
  const summaryCSV = () => {
    const done = loadProgress(X.pid);
    return _.toCSV(SUM_COLS, Object.keys(done).map(Number).sort((a, b) => a - b).map(k => SUM_COLS.map(c => done[k][c] ?? '')));
  };
  const summaryName = () => `${X.pid}_${X.cfg.name}_trials.csv`;

  // ---------- 覆い（設定の画面・開始・完了後） ----------
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function cover(html) {
    $('expCover').hidden = !html;
    if (html) $('expCard').innerHTML = html;
  }
  const errList = errs => `<ul class="expErr">${errs.map(e => `<li>${esc(e)}</li>`).join('')}</ul>`;
  const cond = t => E.conditionFor(X.cfg, t);   // 条件名（experiment.json の condition・conditions。無ければ空）
  const trialName = (t, k) => `${k + 1}. ${t.practice ? '練習　' : ''}${modes[t.mode] ? modes[t.mode].label : t.mode}${cond(t) ? `（${cond(t)}）` : ''}　${t.record ? '（録画）' : t.video}`;
  // 今の試行の動画の名前。録画の試行は選んだ録画のファイル名（選ぶ前は空）
  const vidName = t => (t.record ? ((S.meta.experiment || {}).record || {}).file || '' : t.video);
  // 自動保存のキー（core/storage.js）で動画名の代わりに使う試行の番号。録画の試行と練習の試行は、同じ方式・動画（録画）を何度も評価できるように試行ごとに分ける
  const trialKey = (t, k) => (t.record ? `rec${k + 1}` : t.practice ? `prac${k + 1}` : null);
  // pid0 は初めに選んでおく参加者（やり直しの画面から戻ったとき）
  function setup(cfg, get, res, pid0) {
    const { errors: errs, warnings = [] } = res;
    X = { cfg, get, res, state: 'setup', backup: null };
    if (errs.length) {
      cover(`<h2>実験フォルダの誤り</h2>${errList(errs)}<button id="expCancel" type="button">閉じる</button>`);
      $('expCancel').addEventListener('click', () => { X = null; cover(''); });
      return;
    }
    const pids = Object.keys(cfg.participants);
    cover(`<h2>実験：${esc(cfg.name)}</h2>
      ${warnings.length ? `<p>確かめてください（このままでも始められます）：</p><ul class="expWarn">${warnings.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : ''}
      <label>参加者 <select id="expPid">${pids.map(p => `<option>${esc(p)}</option>`).join('')}</select></label>
      <label>始める試行 <select id="expFrom"></select></label>
      <div class="expBtns"><button id="expGo" type="button">実験を始める</button><button id="expRedoBtn" type="button" title="書き出した試行の zip か _session.json を選び、その評価を戻して直す（別の PC で続けるときなど）">結果のファイルから試行をやり直す</button><button id="expCancel" type="button">やめる</button></div>
      <div class="expSaved"><div class="refTitle">ブラウザに残っている結果</div><div id="expZips" class="expZips"></div></div>
      <p class="muted">実験中は ${_.mod('Ctrl')}+Shift+E で実験モードを抜けます。結果は試行ごとに 1 つの zip としてダウンロード先に書き出し、ブラウザにも残します。</p>`);
    const fill = () => {
      const pid = $('expPid').value, done = loadProgress(pid), ts = cfg.participants[pid];
      const first = ts.findIndex((_t, k) => !done[k] || done[k].partial);
      $('expFrom').innerHTML = ts.map((t, k) => `<option value="${k}">${esc(trialName(t, k))}${done[k] ? (done[k].partial ? '（途中）' : '（済）') : ''}</option>`).join('');
      $('expFrom').value = String(first < 0 ? 0 : first);
      listZips(pid);
    };
    if (pid0 && pids.includes(pid0)) $('expPid').value = pid0;
    $('expPid').addEventListener('change', fill); fill();
    $('expCancel').addEventListener('click', () => { X = null; cover(''); });
    // 終えた試行（（済））を選んだら、やり直し方を選ばせる（取り違えの確認も兼ねる）
    $('expGo').addEventListener('click', () => {
      const pid = $('expPid').value, k = +$('expFrom').value, row = loadProgress(pid)[k];
      if (row && !row.partial) askRedo(pid, k, row); else enter(pid, k);
    });
    $('expRedoBtn').addEventListener('click', () => pickRedo($('expPid').value, null));
  }

  // ---------- 終えた試行をやり直す（実験者向けの画面） ----------
  // 「前の評価を読み込んで直す」はブラウザに残った zip（無ければ実験者が選んだ zip か _session.json）から評価を戻し、「開始」の覆いから続ける。
  // 「空から評価し直す」は値の無い状態から始める。どちらも前の zip は消さず、やり直しの回数・前の完了の時刻を記録に残す
  function askRedo(pid, k, row, msg = '') {
    const t = X.cfg.participants[pid][k], when = row.end_iso ? new Date(row.end_iso).toLocaleString('ja-JP') : '（時刻なし）';
    cover(`<h2>終えた試行をやり直す（実験者の方へ）</h2>
      <p>参加者 ${esc(pid)} の「${esc(trialName(t, k))}」は ${esc(when)} に完了しています${row.redo ? `（やり直し ${row.redo} 回）` : ''}。</p>
      <p class="muted">「前の評価を読み込んで直す」は、完了した評価（値・評価区間・区切り・形の記録）を戻して「開始」から続けます。「空から評価し直す」は、値の無い状態から始めます。どちらも前の zip は残し、新しい zip の名前に _redo と回数を付けます。</p>
      ${msg}
      <div class="expBtns"><button id="expRedoLoad" type="button">前の評価を読み込んで直す</button><button id="expRedoEmpty" type="button">空から評価し直す</button><button id="expRedoBack" type="button">戻る</button></div>`);
    $('expRedoBack').addEventListener('click', () => setup(X.cfg, X.get, X.res, pid));
    $('expRedoEmpty').addEventListener('click', () => { X.redo = redoInfo(row, null, 'empty'); enter(pid, k); });
    $('expRedoLoad').addEventListener('click', async () => {
      const z = await lastZip(pid, k);
      let s = null, err = '';
      if (z) { try { s = await _.readSession(new File([z.blob], z.name)); } catch (e) { err = e.message; } }
      if (s) { X.redo = redoInfo(row, s, 'browser'); enter(pid, k); return; }
      askRedo(pid, k, row, `<p class="expMiss">${z ? `ブラウザに残った zip（${esc(z.name)}）を読めません（${esc(err)}）。` : 'このブラウザにはこの試行の zip が残っていません。'}書き出した zip か _session.json を選んでください。</p>
        <button id="expRedoPick" type="button">ファイルを選ぶ</button>`);
      $('expRedoPick').addEventListener('click', () => pickRedo(pid, k));
    });
  }
  // やり直しの記録：回数は前の回の要約（読み込む評価があればその要約）の redo に 1 を足す。task_ms_prev は前の回までのタスク遂行時間の合計
  function redoInfo(row, s, from) {
    const m = (s && s.meta.experiment) || {}, p = (s ? m.task : row) || {};
    return { n: (+p.redo || 0) + 1, prev_end_iso: p.end_iso || m.end_iso || '', task_ms_prev: +((+p.task_ms_prev || 0) + (+p.task_ms || 0)).toFixed(1), from, session: s };
  }
  // 実験者が zip か _session.json を選ぶ。k が null なら、ファイルの試行の番号（meta.experiment.trial）の試行をやり直す
  function pickRedo(pid, k) {
    X.redoPick = { pid, k };
    $('expRedoFile').click();
  }
  async function takeRedoFile(f) {
    const { pid, k: k0 } = X.redoPick; X.redoPick = null;
    let s;
    try { s = await _.readSession(f); } catch (err) { alert('結果を読み込めませんでした：' + err.message); return; }
    const m = s.meta.experiment || {}, ts = X.cfg.participants[pid], k = k0 != null ? k0 : m.trial;
    if (!Number.isInteger(k) || !ts[k]) { alert(`${f.name} は、参加者 ${pid} の試行の結果ではありません（試行の番号：${Number.isInteger(m.trial) ? m.trial + 1 : 'なし'}）`); return; }
    const t = ts[k];
    if (s.meta.mode !== t.mode) { alert(`${f.name} は方式「${modes[s.meta.mode].label}」の結果です。試行 ${k + 1} の方式「${modes[t.mode] ? modes[t.mode].label : t.mode}」には当てられません`); return; }
    const diff = [];
    if (m.name !== X.cfg.name) diff.push(`実験：${m.name || 'なし'}（この実験は ${X.cfg.name}）`);
    if (m.participant !== pid) diff.push(`参加者：${m.participant || 'なし'}（選んだ参加者は ${pid}）`);
    if (m.trial !== k) diff.push(`試行：${Number.isInteger(m.trial) ? m.trial + 1 : 'なし'}（やり直す試行は ${k + 1}）`);
    if (!t.record && s.meta.video_file !== t.video.split('/').pop()) diff.push(`動画：${s.meta.video_file}（この試行は ${t.video}）`);
    if (m.partial) diff.push('途中で抜けた試行の結果です（_partial）');
    if (diff.length && !confirm(`選んだファイル（${f.name}）は、この試行の結果と次の点が違います。\n${diff.map(d => '・' + d).join('\n')}\nこのファイルの評価で直しますか？`)) return;
    X.redo = redoInfo(null, s, 'file');
    enter(pid, k);
  }
  // 参加者の zip の一覧：1 つずつ・まとめて書き出し直す。書き出しを確かめたら、ブラウザから消せる（進行と自動保存も消す）
  async function listZips(pid) {
    const box = $('expZips'); if (!box) return;
    let zs = [];
    try { zs = (await zipAll()).filter(z => z.exp === X.cfg.name && z.pid === pid).sort((a, b) => a.trial - b.trial || a.time - b.time); } catch (_e) { box.textContent = 'ブラウザの保存領域を読めません'; return; }
    if (!X || $('expPid').value !== pid) return;
    if (!zs.length) { box.innerHTML = '<p class="muted">まだありません</p>'; return; }
    box.innerHTML = `<ul>${zs.map((z, k) => `<li><button type="button" data-k="${k}">書き出す</button> ${esc(z.name)}</li>`).join('')}</ul>
      <div class="expBtns"><button id="expZipAll" type="button">すべて書き出す</button><button id="expZipDel" type="button">この参加者の記録をブラウザから消す</button></div>`;
    box.querySelectorAll('button[data-k]').forEach(b => b.addEventListener('click', () => downloadBlob(zs[+b.dataset.k].name, zs[+b.dataset.k].blob)));
    $('expZipAll').addEventListener('click', () => zs.forEach(z => downloadBlob(z.name, z.blob)));
    $('expZipDel').addEventListener('click', async () => {
      if (!confirm(`参加者 ${pid} の記録（zip・進行・途中の自動保存）をこのブラウザから消します。書き出したファイルを確かめましたか？`)) return;
      await zipDel(X.cfg.name, pid);
      try {
        localStorage.removeItem(progKey(pid));
        X.cfg.participants[pid].forEach((t, k) => localStorage.removeItem(`ahann4:${t.mode}:${pid}:${trialKey(t, k) || t.video.split('/').pop()}`));
      } catch (_e) {}
      $('expPid').dispatchEvent(new Event('change'));
    });
  }

  // ---------- 実験モードに入る・抜ける ----------
  function enter(pid, from) {
    X.pid = pid; X.trials = X.cfg.participants[pid];
    X.backup = {};
    for (const k of LS_KEYS) { try { X.backup[k] = localStorage.getItem(k); } catch (_e) {} }
    _.closePops();
    $('pid').value = pid; S.meta.participant = pid;
    document.body.classList.add('exp');
    trap();
    startTrial(from);
  }
  function restoreSettings() {
    if (!X || !X.backup) return;
    for (const [k, v] of Object.entries(X.backup)) { try { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (_e) {} }
  }
  async function exit() {
    const running = X.state === 'running';
    if (!confirm(`実験モードを終了しますか？${running ? '（今の試行は途中までを _partial の zip として書き出します）' : ''}（ページを読み込み直し、設定を実験前に戻します）`)) return;
    if (running) {
      if (!video.paused) video.pause();
      endStroke('exp_exit'); addLog('task_abort', { value: X.i + 1 });
      S.meta.experiment.partial = true;
      const row = { ...summarize(), partial: 1 };
      S.meta.experiment.task = row; saveProgress(X.i, row);
      await saveZip(true);
      await new Promise(r => setTimeout(r, 800));   // ダウンロードが始まるのを待ってから読み込み直す
    } else if (video.src && S.meta.video_file) { endStroke('exp_exit'); _.autosave(); }
    restoreSettings(); X = null;
    location.reload();
  }
  window.addEventListener('pagehide', () => restoreSettings());

  // ---------- 実験モードの間はページを離れない ----------
  // マウスの戻る・進むボタンとトラックパッドのスワイプでは前のページへ移らず、ページやウィンドウを閉じるときは確認を出す（Chrome・Edge・Firefox）。
  // Ctrl+Shift+E で抜けるときは X を空にしてから読み込み直すので、確認は出ない
  const guarded = () => !!X && !!X.backup;
  // 履歴を 1 つ積んでおき、戻ったら積み直す（ボタンを止められないブラウザや、スワイプで戻ったときもこのページに留まる）
  function trap() { try { history.pushState({ ahExp: 1 }, ''); } catch (_e) {} }
  window.addEventListener('popstate', () => { if (guarded()) trap(); });
  // マウスの戻る（button 3）・進む（button 4）
  for (const t of ['mousedown', 'mouseup', 'auxclick']) window.addEventListener(t, e => { if (guarded() && (e.button === 3 || e.button === 4)) e.preventDefault(); }, true);
  window.addEventListener('beforeunload', e => { if (!guarded()) return; e.preventDefault(); e.returnValue = ''; });

  // ---------- 設定を当てる ----------
  // 各欄の既存の処理（操作ログ・ブラウザへの保存）をそのまま使うため、欄の値を変えて change を送る
  function applySettings(s) {
    const fire = (id, prop, v) => { const el = $(id); if (el[prop] === v) return; el[prop] = v; el.dispatchEvent(new Event('change')); };
    _.setAxes(s.axes);
    fire('rate', 'value', String(s.rate));
    fire('afterWrite', 'value', s.afterWrite);
    fire('graphEdit', 'checked', !!s.graphEdit);
    fire('gridShow', 'checked', !!s.grid);
    fire('padSquare', 'checked', !!s.padSquare);
    fire('padJoyUse', 'checked', !!s.padJoy);
    fire('padSliderUse', 'checked', !!s.padSlider);
    _.setF0Shown(!!s.f0); _.setVoicedShown(!!s.voiced, 'exp'); _.setListen(!!s.listen); _.setTimeline(!!s.timeline); _.setVideoSize(+s.videoSize);
    document.body.classList.toggle('expReview', !!s.review);
    document.body.classList.toggle('expRef', !!s.refAudio);
    document.body.classList.toggle('expVoicedBtn', !!s.voicedBtn);
    document.body.classList.toggle('expVoice', !!s.voice);
    document.body.classList.toggle('expVwin', !!s.videoWindow);
  }
  // 評価区間を当てる。動画の長さに収まらなければ誤りの文を返す（黙って切り詰めない。フレームの端数 0.02 秒は許す）
  // 参加者が自分で区切る試行（Excel の cuts: "self"）は、区切りの無い 1 区間（開始〜終了）から始める。
  // 1秒固定（cuts: "sec1"）の試行は、開始〜終了を 1 秒ごとに区切る（setup.json の区切りは使わない）
  function applyRange(r) {
    const D = S.meta.duration, tol = 0.02, label = r.label || 'countdown';
    const self = !!(_.M && _.M.selfCuts && _.M.selfCuts()), sec1 = !!(_.M && _.M.cutsMode && _.M.cutsMode() === 'sec1');
    if (r.edges) {
      const e = r.edges, end = e[e.length - 1];
      if (end > D + tol) return `評価区間の終了（${end} 秒）が動画の長さ（${D.toFixed(3)} 秒）を超えています`;
      const edges = self ? [e[0], end] : e.slice(); edges[edges.length - 1] = Math.min(end, D);
      if (sec1) { const s0 = edges[0], e1 = edges[edges.length - 1]; _.setRange({ edges: null, start: s0, bin: 1, label, target: e1, count: _.countFor(s0, Math.max(s0 + 1, e1), 1) }); return null; }
      _.setRange({ edges, start: edges[0], target: edges[edges.length - 1], count: edges.length - 1, bin: r.bin || 1, label });
      return null;
    }
    const start = r.start || 0, end = r.end != null ? r.end : D, bin = r.bin || 1;
    if (end > D + tol) return `評価区間の終了（${end} 秒）が動画の長さ（${D.toFixed(3)} 秒）を超えています`;
    if (start >= Math.min(end, D)) return `評価区間の開始（${start} 秒）が終了より後ろです`;
    const e = Math.min(end, D);
    if (sec1) _.setRange({ edges: null, start, bin: 1, label, target: e, count: _.countFor(start, Math.max(start + 1, e), 1) });
    else if (self) _.setRange({ edges: [start, e], start, bin, label, target: e, count: 1 });
    else _.setRange({ edges: null, start, bin, label, target: e, count: _.countFor(start, Math.max(start + bin, e), bin) });
    return null;
  }

  // ---------- 試行 ----------
  // 前の試行を片づけてから、方式・設定を当てて動画を開く。片づけで video_file を空にし、新しい試行の値が前の動画の保存先に入らないようにする
  function teardown() {
    if (!video.paused) video.pause();
    if (_.reviewing()) _.setReview(false);
    if (_.setVoice) _.setVoice(false);
    if (document.body.classList.contains('vwin') && _.closeVideoWindow) _.closeVideoWindow();
    endStroke('trial'); setArmed(false); pen.down = false;
    if (video.src) _.autosave();
    S.meta.video_file = ''; delete S.meta.save_key; delete S.meta.novoice_preset; S.data = null; S.undo = []; S.redo = []; S.log = [];
  }
  function startTrial(i) {
    teardown();
    const t = X.trials[i];
    X.i = i; X.file = null;
    X.set = { ...DEF, ...(X.cfg.settings || {}), ...(t.settings || {}) };
    X.range = E.rangeFor(X.cfg, t);
    _.selectMode(t.mode);
    S.meta.options = { ...S.meta.options, ...(t.options || {}) };
    applySettings(X.set);
    _.remount();
    if (t.record) { setState('pick'); return; }
    if (trialKey(t, i)) S.meta.save_key = trialKey(t, i);
    setState('loading');
    _.openVideoFile(X.get(t.video), () => loaded(i));
  }
  // 試行の進み：操作ログの最後の task_start・task_end・exp_redo で決める（やり直した試行は、前の回の task_start・task_end がログに残る）。
  // new（まだ始めていない）・redo（やり直しの開始の前）・running（開始の後）・ended（完了の後）
  function phase(log) {
    for (let k = log.length - 1; k >= 0; k--) {
      const ty = log[k].type;
      if (ty === 'exp_redo') return 'redo';
      if (ty === 'task_start') return 'running';
      if (ty === 'task_end') return 'ended';
    }
    return 'new';
  }
  function loaded(i) {
    const t = X.trials[i];
    // やり直し：自動保存から同じ回のやり直しを再開したときは当て直さない。評価を読み込むときは、方式の設定・値・評価区間・形の記録・操作ログを戻す
    let r = X.redo; X.redo = null;
    const cur = S.meta.experiment && S.meta.experiment.trial === i && S.meta.experiment.redo;
    if (r && cur && cur.n === r.n) r = null;
    if (r && r.session) {
      if (t.record && r.session.meta.video_file !== S.meta.video_file
        && !confirm(`読み込む評価は録画「${r.session.meta.video_file}」の評価です。開いた録画「${S.meta.video_file}」に当てますか？\n（キャンセルすると、録画を選び直します）`)) { X.redo = r; setState('pick'); return; }
      _.installSession(r.session);
      S.meta.participant = X.pid; $('pid').value = X.pid;
    }
    const log = S.log, ph = phase(log);
    const vs = (!t.record && X.cfg.videos && X.cfg.videos[t.video]) || {};
    S.meta.ref = typeof vs.ref === 'number' ? vs.ref : null;   // 基準音声の時刻（setup.json。無ければ最初の声。core/ref.js）
    // 基準音声の動画：setup.json の refVideo。録画の試行は実験者が選んだ録画（同じ参加者の後の試行にも使う）。無ければ評価する動画の最初の声
    if (t.record) _.setRefVideo(X.refFile, 'record');
    else _.setRefVideo(vs.refVideo ? X.get(vs.refVideo) : null, 'setup');
    // 発声なしの区間（setup.json の novoice。PANAS で事前に印を付け、参加者は変えられない．modes/panas.js）
    const vnv = vs.novoice;
    if (Array.isArray(vnv) && vnv.length) S.meta.novoice_preset = vnv.map(x => [x[0], x[1]]); else delete S.meta.novoice_preset;
    S.meta.experiment = { ...(S.meta.experiment && S.meta.experiment.trial === i ? S.meta.experiment : {}),
      name: X.cfg.name, participant: X.pid, trial: i, n_trials: X.trials.length, practice: !!t.practice, condition: cond(t), settings: X.set, options: { ...S.meta.options } };
    if (r) {
      const ex = S.meta.experiment;
      delete ex.start_iso; delete ex.end_iso; delete ex.task; delete ex.partial;
      ex.redo = { n: r.n, prev_end_iso: r.prev_end_iso, task_ms_prev: r.task_ms_prev, from: r.from };
      addLog('exp_redo', { value: r.n, detail: JSON.stringify({ ...ex.redo, file: r.session ? r.session.name : '' }) });
      if (ph !== 'new') {   // 読み込んだ評価の区間のまま「開始」の覆いへ。録画の試行は、開いた録画を記録し、進行に区間が無ければ（別の PC）残す
        if (t.record) {
          const rec = openedRec(ex.record || {});
          ex.record = rec;
          if (!loadRec(i) && rec.start != null) saveRec(i, { file: rec.file, size: rec.size, duration: rec.duration, start: rec.start, end: rec.end });
        }
        logTrial(S.meta.range);
        setState('ready');
        return;
      }
    }
    if (ph === 'new' && t.record) {
      // 渡した後に止まった試行は、残した区間で開始の覆いに戻る（区間が録画に収まらなければ合わせ直す）。まだなら区間合わせ
      const prev = loadRec(i);
      if (prev && !applyRange(recRange(prev))) { handOff(prev); return; }
      delete S.meta.experiment.record;
      X.align = { start: 0, end: S.meta.duration };
      setState('align'); showAlign();
      return;
    }
    if (ph === 'new') {   // 復元したときは、その時点の評価区間のまま続ける
      const err = applyRange(X.range);
      if (err) { setState('error', err); return; }
      logTrial(X.range);
    }
    setState(ph === 'ended' ? (nextTrial(i) >= 0 ? 'done' : 'finished') : ph === 'running' ? 'running' : 'ready');
  }
  function logTrial(range) {
    const t = X.trials[X.i];
    addLog('exp_trial', { value: X.i + 1, detail: JSON.stringify({ name: X.cfg.name, mode: t.mode, condition: cond(t), video: vidName(t), ...(t.record ? { record: true } : {}), practice: !!t.practice, range }) });
  }

  // ---------- 録画の試行（record: true） ----------
  // 実験者が録画を選び（pick）、動画を見ながら開始・終了を合わせて（align）から参加者に渡す（ready）。
  // 区切り（bin・label・Excel の cuts）は動画の試行と同じく applyRange が決める（edges の区切りは録画ごとに長さが違うので使わない）。
  // 渡した録画（名前・大きさ）と区間は進行に残し、中断したら同じ録画を選び直してもらう。自動保存のキーは試行の番号（rec1 など）
  const recRange = rec => { const r = { ...X.range, start: rec.start, end: rec.end }; delete r.edges; return r; };
  function pickFile(f) {
    const prev = loadRec(X.i);
    if (prev && (f.name !== prev.file || f.size !== prev.size)
      && !confirm(`前に選んだ録画（${prev.file}，${prev.size} バイト）と違います（${f.name}，${f.size} バイト）。このファイルで続けますか？`)) return;
    X.file = f;
    S.meta.save_key = trialKey(X.trials[X.i], X.i);   // core/storage.js の自動保存のキー
    setState('loading');
    _.openVideoFile(f, () => loaded(X.i));
  }
  // 区間合わせ：合わせている区間を評価グラフに 1 区間として出し、実験者用の帯を作り直す
  function showAlign(msg) {
    const { start, end } = X.align;
    if (start < end) _.setRange({ edges: [start, end], start, target: end, count: 1, bin: X.range.bin || 1, label: X.range.label || 'countdown' });
    const f3 = x => x.toFixed(3);
    $('expAlign').innerHTML = `<b>評価区間を合わせる（実験者）</b><span>${esc(X.file.name)}</span>`
      + `<span>開始 ${f3(start)} 秒 〜 終了 ${f3(end)} 秒（動画 ${f3(S.meta.duration)} 秒）</span>`
      + '<span class="expBtns"><button id="expRecStart" type="button">今の時間を開始にする</button><button id="expRecEnd" type="button">今の時間を終了にする</button></span>'
      + `<span>基準音声：${X.refFile ? '「' + esc(X.refFile.name) + '」の最初の声' : 'この録画の最初の声'}</span>`
      + `<span class="expBtns"><button id="expRecRef" type="button">基準音声の録画を選ぶ</button>${X.refFile ? '<button id="expRecRefOff" type="button">外す</button>' : ''}</span>`
      + '<span class="expBtns"><button id="expRecRepick" type="button">動画を選び直す</button><button id="expRecGo" type="button" class="expDone">参加者に渡す</button></span>'
      + (msg ? `<span class="expMiss">${esc(msg)}</span>` : '');
    const now = () => _.frameStart(video.currentTime);
    const bind = (id, fn) => $(id).addEventListener('click', e => { e.currentTarget.blur(); fn(); });
    bind('expRecStart', () => { X.align.start = now(); showAlign(); });
    bind('expRecEnd', () => { X.align.end = now(); showAlign(); });
    bind('expRecRef', () => $('expRefFile').click());
    if (X.refFile) bind('expRecRefOff', () => setRef(null));
    bind('expRecRepick', () => { if (!video.paused) video.pause(); setState('pick'); });
    bind('expRecGo', () => {
      const D = S.meta.duration, a = X.align;
      if (!(a.start < a.end)) { showAlign('開始が終了より後ろです。合わせ直してください'); return; }
      const rec = { file: X.file.name, size: X.file.size, duration: +D.toFixed(3), start: +a.start.toFixed(4), end: +a.end.toFixed(4) };
      const err = applyRange(recRange(rec));
      if (err) { showAlign(err); return; }
      if (!video.paused) video.pause();
      _.seekTo(0);   // 区間合わせで動かした位置のまま渡さない（動画の試行と同じく最初から始める）
      saveRec(X.i, rec);
      handOff(rec);
    });
  }
  // 開始の覆いから区間合わせに戻る。前に合わせた区間から始める。操作ログには合わせ直したことを残し、渡し直したときの exp_record・exp_trial を正とする
  function realignRec() {
    if (!X || X.state !== 'ready') return;
    const rec = loadRec(X.i) || S.meta.experiment.record || {};
    X.align = rec.start != null && rec.end != null ? { start: rec.start, end: rec.end } : { start: 0, end: S.meta.duration };
    addLog('exp_realign', { value: X.i + 1 });
    setState('align'); showAlign();
  }
  // 録画の試行の基準音声の録画（null なら評価する録画の最初の声）。参加者ごとに進行に残し、中断の後に選び直す案内に使う
  function setRef(f) {
    X.refFile = f;
    const prog = loadProg(X.pid); writeProg({ ...prog, refVideo: f ? { file: f.name, size: f.size } : null });
    _.setRefVideo(f, 'record');
    showAlign();
  }
  // 区間を当てた後：記録して開始の覆いへ。中断の後に選び直した録画が違っても、実際に開いた録画を残す
  // 実際に開いた録画と基準音声の録画を record に書く。名前・大きさ・更新日時は、回収ツールが録画のファイルを確実に見つけるために残す
  function openedRec(prev) {
    const rec = { ...prev, file: X.file.name, size: X.file.size, last_modified: X.file.lastModified, duration: +S.meta.duration.toFixed(3) };
    if (X.refFile) Object.assign(rec, { ref_video: X.refFile.name, ref_video_size: X.refFile.size, ref_video_last_modified: X.refFile.lastModified });
    else { delete rec.ref_video; delete rec.ref_video_size; delete rec.ref_video_last_modified; }
    return rec;
  }
  function handOff(prev) {
    const rec = openedRec(prev);
    S.meta.experiment.record = rec;
    addLog('exp_record', { detail: JSON.stringify(rec) });
    logTrial(recRange(rec));
    setState('ready');
  }
  const progText = () => { const t = X.trials[X.i]; return `${X.i + 1} / ${X.trials.length}${t.practice ? '　練習' : ''}${cond(t) ? '　' + cond(t) : ''}`; };
  function setState(st, msg) {
    X.state = st;
    document.body.classList.toggle('expWait', st !== 'running');
    document.body.classList.toggle('expAligning', st === 'align');
    $('expAlign').hidden = st !== 'align';
    $('expInfo').hidden = false; $('expInfo').textContent = progText();
    $('expDoneBtn').hidden = st !== 'running';
    const head = `<p class="expProg">${esc(progText())}</p>`;
    if (st === 'loading') cover(head + '<p>読み込んでいます…</p>');
    else if (st === 'error') cover(head + `<h2>この試行を始められません</h2>${errList([`${vidName(X.trials[X.i])}：${msg}`])}<p>実験者の方へ：setup.json（動画ごとの評価区間）を直してから、${_.mod('Ctrl')}+Shift+E で抜けて実験フォルダを開き直してください。</p>`);
    else if (st === 'pick') {
      const prev = loadRec(X.i), pref = loadProg(X.pid).refVideo;
      cover(head + '<h2>録画を選ぶ（実験者の方へ）</h2>'
        + (prev ? `<p>この試行は「${esc(prev.file)}」で始めています。同じ録画を選び直してください。</p>`
          : '<p>この試行で評価する録画のファイルを選んでください。選んだ後、動画を見ながら評価区間の開始と終了を合わせます。</p>')
        + (pref && !X.refFile ? `<p>基準音声の録画に「${esc(pref.file)}」を選んでいました。評価区間を合わせる画面で選び直してください。</p>` : '')
        + '<button id="expRecPick" type="button" class="expMain">録画した動画を選ぶ</button>');
      $('expRecPick').addEventListener('click', e => { e.currentTarget.blur(); $('expRecFile').click(); });
    } else if (st === 'align') cover('');
    else if (st === 'ready') {
      // 録画の試行は、参加者が「開始」を押す前なら実験者が評価区間を合わせ直せる（やり直しの回は読み込んだ評価があるので出さない）
      const realign = X.trials[X.i].record && X.file && !S.meta.experiment.redo;
      cover(head + '<p>準備ができたら「開始」を押してください。</p><button id="expStart" type="button" class="expMain">開始</button>'
        + (realign ? '<p class="expRealign"><button id="expRealign" type="button">評価区間を合わせ直す（実験者の方へ）</button></p>' : ''));
      $('expStart').addEventListener('click', start);   // フォーカスは置かない（Space で誤って始めないように）
      if (realign) $('expRealign').addEventListener('click', e => { e.currentTarget.blur(); realignRec(); });
    } else if (st === 'done' || st === 'finished') {
      // アンケートがある試行は、すべての「アンケートを開く」を押すまで「次へ」（残りが無ければ終わりの案内）を出さない。最後の試行の後には finalSurvey も出す
      // （やり直した試行の後に残りが無くても、最後の試行でなければ finalSurvey は出さない）
      const last = st === 'finished', sv = surveys(X.i, X.i + 1 >= X.trials.length), opened = new Set();
      const next = last ? '<p>すべての試行が終わりました。ありがとうございました。</p><button id="expSum" type="button">要約をもう一度書き出す</button>'
        : '<button id="expNext" type="button" class="expMain">次へ</button>';
      const many = sv.length > 1;
      cover(head + '<p>完了しました。</p>' + (sv.length ? `<p>アンケートに答えてください${many ? `（${sv.length} つあります。上から順に答えてください）` : ''}。答え終わったら、この画面に戻ってください。</p>`
        + `<div class="expSurveys">${sv.map((s, k) => `<button id="expSurvey${k ? k + 1 : ''}" type="button" class="expMain expSurvey">${esc(s.label || (many ? `アンケート ${k + 1} を開く` : 'アンケートを開く'))}</button>`).join('')}</div>` : '')
        + `<div id="expAfter"${sv.length ? ' hidden' : ''} class="expAfter">${next}</div>`);
      sv.forEach((s, k) => $('expSurvey' + (k ? k + 1 : '')).addEventListener('click', e => {
        window.open(s.url, '_blank');
        opened.add(k); e.currentTarget.classList.add('expOpened');
        saveProgress(X.i, { survey_opened: opened.size });   // 完了の後なので、操作ログではなく要約に残す
        if (opened.size === sv.length) $('expAfter').hidden = false;
      }));
      if (last) $('expSum').addEventListener('click', () => _.download(summaryName(), summaryCSV(), 'text/csv'));
      else $('expNext').addEventListener('click', () => startTrial(nextTrial(X.i)));
    } else cover('');
  }
  // 次に進む試行：i より後で、終えていない最初の試行（途中で抜けたものを含む）。無ければ -1。
  // やり直した試行の後は、終えた試行を飛ばす（「次へ」で終えた試行を空から始めない）
  function nextTrial(i) {
    const done = loadProgress(X.pid);
    for (let k = i + 1; k < X.trials.length; k++) if (!done[k] || done[k].partial) return k;
    return -1;
  }
  // アンケートの一覧 [{ url, label }]：試行の survey（false なら無し）、なければ全体の survey（練習の試行には使わない）。
  // final なら、実験の後に 1 回だけ答える finalSurvey を後ろに足す。
  // どちらも URL の文字列か、URL の文字列・{ url, label } の配列。{pid} などを試行の値に置き換える
  function surveys(i, final) {
    const t = X.trials[i];
    const val = { pid: X.pid, trial: i + 1, mode: t.mode, condition: cond(t), video: vidName(t), practice: t.practice ? 1 : 0, name: X.cfg.name };
    const fill = u => u.replace(/\{(pid|trial|mode|condition|video|practice|name)\}/g, (_m, k) => encodeURIComponent(val[k]));
    const list = tpl => !tpl ? [] : (Array.isArray(tpl) ? tpl : [tpl]).map(s => typeof s === 'string' ? { url: fill(s) } : { url: fill(s.url), label: s.label });
    return [...list(t.survey !== undefined ? t.survey : t.practice ? null : X.cfg.survey), ...(final ? list(X.cfg.finalSurvey) : [])];
  }
  function start() {
    if (!X || X.state !== 'ready') return;
    S.meta.experiment.start_iso = new Date().toISOString();
    addLog('task_start', { value: X.i + 1 });
    setState('running');
  }
  async function complete() {
    if (!X || X.state !== 'running') return;
    if (!confirm('評価を終えて完了しますか？（完了すると、この動画の評価は変えられません）')) return;
    if (!video.paused) video.pause();
    if (_.reviewing()) _.setReview(false);
    if (_.setVoice) _.setVoice(false);
    endStroke('task_end'); setArmed(false); pen.down = false;
    S.meta.experiment.end_iso = new Date().toISOString();
    addLog('task_end', { value: X.i + 1 });
    const row = { ...summarize(), partial: 0, survey_opened: 0 };
    S.meta.experiment.task = row;
    saveProgress(X.i, row);
    setState(nextTrial(X.i) >= 0 ? 'done' : 'finished');
    await saveZip(false);
  }
  // 今の試行を 1 つの zip にして書き出し、ブラウザにも残す。書き出せたら、この試行の自動保存は消す（ブラウザの容量を空けるため）。
  // やり直した回は名前に _redo1 などを付け、前の回の zip と同じ名前にしない（ダウンロード先で (1) が付かず、ブラウザの zip も上書きしない）
  async function saveZip(partial) {
    const files = _.buildFiles(); if (!files) return;
    files.push({ name: summaryName(), text: summaryCSV() });
    const session = files.find(f => f.name.endsWith('_session.json')).name, rd = S.meta.experiment.redo;
    const name = session.replace(/_session\.json$/, `${rd ? `_redo${rd.n}` : ''}${partial ? '_partial' : ''}.zip`);
    const blob = new Blob([_.makeZip(files.map(f => ({ name: f.name, data: '﻿' + f.text })))], { type: 'application/zip' });
    downloadBlob(name, blob);
    $('status').textContent = `書き出しました（${name}）`;
    const key = _.saveKey();
    try {
      await zipPut(`${X.cfg.name}|${X.pid}|${X.i}${rd ? `|redo${rd.n}` : ''}${partial ? '|partial' : ''}`, { name, blob, exp: X.cfg.name, pid: X.pid, trial: X.i, time: Date.now() });
      if (!partial) { S.meta.video_file = ''; localStorage.removeItem(key); }   // video_file を空にして、以後の操作で自動保存を作り直さない
    } catch (_e) { /* 残せなくても、ダウンロードと自動保存はある */ }
  }

  // ---------- 要約 ----------
  // 最後の task_start から task_end（なければ今）までの操作ログを数える。再生・視聴の時間は、開始と終わりの組の間の合計。
  // 途中で抜けて（task_abort）再開した試行も、抜けていた間は経過時間に入らない（再開すると操作ログの経過時間が続きから数える）。
  // やり直した試行も、やり直した回（最後の task_start から）だけを数える。前の回までのタスク遂行時間は task_ms_prev に別に残す
  function summarize() {
    const log = S.log, t = X.trials[X.i], rd = S.meta.experiment.redo;
    let k0 = -1; for (let k = log.length - 1; k >= 0; k--) if (log[k].type === 'task_start') { k0 = k; break; }
    const seg = k0 < 0 ? [] : log.slice(k0);
    const kEnd = seg.findIndex(l => l.type === 'task_end');
    const span = kEnd < 0 ? seg : seg.slice(0, kEnd + 1);
    const w0 = span.length ? span[0].wall_ms : 0, w1 = span.length ? span[span.length - 1].wall_ms : 0;
    const n = type => span.filter(l => l.type === type).length;
    let play = 0, playAt = null, rev = 0, revAt = null;
    for (const l of span) {
      if (l.type === 'play' && playAt == null) playAt = l.wall_ms;
      else if ((l.type === 'pause' || l.type === 'ended') && playAt != null) { play += l.wall_ms - playAt; playAt = null; }
      else if (l.type === 'review' && l.value === 'on' && revAt == null) revAt = l.wall_ms;
      else if (l.type === 'review' && l.value === 'off' && revAt != null) { rev += l.wall_ms - revAt; revAt = null; }
    }
    if (playAt != null) play += w1 - playAt;
    if (revAt != null) rev += w1 - revAt;
    // 値を入れた区間の数。区間内で変化（core/curve.js）の変化の区間は、書き込みがかかった区間を数える
    const bins = _.nSec(), filled = ax => _.M.filledCount ? _.M.filledCount(ax) : S.data.cells[ax].slice(0, bins).filter((x, s) => (x === 'curve' ? (_.curveInfo(ax, s) || {}).entered : x != null && x !== '')).length;
    return { trial: X.i + 1, practice: t.practice ? 1 : 0, mode: t.mode, condition: cond(t), video: vidName(t),
      start_iso: S.meta.experiment.start_iso || '', end_iso: S.meta.experiment.end_iso || '',
      task_ms: +(w1 - w0).toFixed(1), play_ms: +play.toFixed(1), review_ms: +rev.toFixed(1),
      n_play: n('play'), n_seek: n('seek'), n_undo: n('undo'), n_redo: n('redo'),
      n_strokes: S.data.strokes.length, n_events: S.data.events.length, bins, filled_v: filled('v'), filled_a: filled('a'),
      n_restore: log.filter(l => l.type === 'restore').length,
      redo: rd ? rd.n : 0, prev_end_iso: rd ? rd.prev_end_iso : '', task_ms_prev: rd ? rd.task_ms_prev : 0 };
  }

  // ---------- 実験用の設定（setup.json）を書き出す（通常の画面） ----------
  // 設定の欄は exp-check.js の SETTINGS から作る。フォルダに setup.json があればその値を、無い項目は今の画面の値を初めの値にする
  // （手や Agent で直した設定を、評価区間を直すための書き出し直しで消さないため）。動画はフォルダの中のものを並べ、
  // それぞれに覚えてある評価区間（通常の画面で合わせたもの）を付ける。覚えていなければ setup.json の区間を使い、どちらも無い動画は「未設定」と出して書き出さない。
  // 基準音声の時刻 ref と発声なしの区間 novoice は書き出しの画面では作らないので、setup.json にあれば引き継ぐ
  // 録画の試行の録画をフォルダに入れたときは、発声者の結果（zip か _session.json）から評価区間と区切りを取り込める（core/speaker.js）
  function currentSettings() {
    return { ...DEF, axes: _.axesId(), rate: +$('rate').value, afterWrite: $('afterWrite').value, timeline: !document.body.classList.contains('noTl'),
      graphEdit: $('graphEdit').checked, grid: _.gridShown(), f0: _.f0Shown(), voiced: _.voicedShown(), listen: _.listenOn(), videoSize: +$('vidSize').value,
      padJoy: $('padJoyUse').checked, padSlider: $('padSliderUse').checked, padSquare: _.padSquare() };
  }
  function durationOf(file) {
    return new Promise(ok => {
      const v = document.createElement('video'), url = URL.createObjectURL(file);
      const done = d => { clearTimeout(tm); URL.revokeObjectURL(url); v.removeAttribute('src'); ok(d); };
      const tm = setTimeout(() => done(null), 10000);
      v.preload = 'metadata'; v.muted = true;
      v.onloadedmetadata = () => done(v.duration); v.onerror = () => done(null);
      v.src = url;
    });
  }
  // 覚えてある評価区間（range.js の形）を setup.json の形にする
  function videoEntry(r, dur) {
    const r4 = x => +(+x).toFixed(4), d = dur ? { duration: +dur.toFixed(3) } : {};
    if (r.edges) return { edges: r.edges.map(r4), label: r.label || 'countdown', ...d };
    const full = r.start + r.count * r.bin;
    const end = r.target != null ? Math.min(full, Math.max(r.target, full - r.bin + 1e-3)) : full;
    return { start: r4(r.start), end: r4(end), bin: r.bin, label: r.label || 'countdown', ...d };
  }
  async function setupExport(list) {
    const { videos, setupFile, cfgFile } = readFolder(list);
    cover('<h2>実験用設定を保存する</h2><p>フォルダの動画を調べています…</p>');
    let old = null, oldErr = '', cfg = null;
    try { old = setupFile ? await readJSON(setupFile) : null; } catch (err) { oldErr = err.message; }
    try { cfg = cfgFile ? await readJSON(cfgFile) : null; } catch (_e) {}
    const oldSet = old && isObj(old.settings) ? old.settings : {}, oldVids = old && isObj(old.videos) ? old.videos : {};
    const refPaths = new Set(Object.values(oldVids).filter(e => isObj(e) && typeof e.refVideo === 'string').map(e => e.refVideo));   // 基準音声の動画（評価区間は要らない）
    // 表に出す動画：フォルダ直下の動画、experiment.json の試行が挙げた動画、setup.json にある動画（基準音声の動画を含む）。
    // 下の階層に置いたゲーム・ツール・回収した録画（データ）の動画は、名前を挙げていなければ出さない
    const named = new Set([...Object.keys(oldVids), ...refPaths]);
    if (cfg && isObj(cfg.participants)) for (const ts of Object.values(cfg.participants)) if (Array.isArray(ts)) for (const t of ts) if (isObj(t) && typeof t.video === 'string') named.add(t.video.replace(/^\.\//, '').replace(/\\/g, '/'));
    const shown = videos.filter(v => !v.path.includes('/') || named.has(v.path)), nHidden = videos.length - shown.length;
    const rows = [];
    for (const v of shown) {
      const dur = await durationOf(v.file);
      const r = dur ? _.loadRange(v.file.name, `${v.file.size}:${dur.toFixed(2)}`) : null;
      const prev = isObj(oldVids[v.path]) ? oldVids[v.path] : null;
      const entry = r ? { ...videoEntry(r, dur), ...(prev && typeof prev.ref === 'number' ? { ref: prev.ref } : {}), ...(prev && typeof prev.refVideo === 'string' ? { refVideo: prev.refVideo } : {}),
        ...(prev && Array.isArray(prev.novoice) ? { novoice: prev.novoice } : {}) } : prev;
      rows.push({ path: v.path, dur, entry, kept: !r && !!prev, refOnly: !r && !prev && refPaths.has(v.path) });
    }
    const cur = { ...currentSettings(), ...Object.fromEntries(E.SETTINGS.filter(d => d.key in oldSet).map(d => [d.key, oldSet[d.key]])) };
    const ctl = d => {
      const id = 'es_' + d.key, v = cur[d.key];
      if (d.type === 'check') return `<label class="chk"><input id="${id}" type="checkbox"${v ? ' checked' : ''}> ${esc(d.label)}</label>`;
      if (d.type === 'number') return `<label>${esc(d.label)} <input id="${id}" type="number" min="${d.min}" max="${d.max}" value="${v}"></label>`;
      const ch = d.key === 'axes' ? Object.entries(_.AXES).map(([k, s]) => [k, s.label]) : d.choices;
      return `<label>${esc(d.label)} <select id="${id}">${ch.map(([k, l]) => `<option value="${k}"${String(k) === String(v) ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`;
    };
    const span = e => (e.edges ? `${e.edges[0]}〜${e.edges[e.edges.length - 1]} 秒（自分で区切った ${e.edges.length - 1} 区間）` : `${e.start}〜${e.end} 秒，${e.bin} 秒ごと`);
    const cell = r => (r.entry ? esc(span(r.entry)) + (r.from ? `（発声者 ${esc(r.from)} から）` : r.kept ? '（setup.json のまま）' : '') : r.refOnly ? '基準音声の動画（評価区間は要りません）' : '<b class="expMiss">未設定</b>');
    let notes = [];   // 発声者の結果を取り込んだときの案内
    // 設定は「基本」と「高度な設定」のタブに分け、初めは基本を出す。高度な設定に既定と違う値があれば、
    // 変えた値が見えないところに隠れないよう、タブの名前に「変更あり」と出す
    let advTab = false;
    const advChanged = () => E.SETTINGS.some(d => d.adv && String(cur[d.key]) !== String(d.def));
    const readForm = () => { for (const d of E.SETTINGS) { const el = $('es_' + d.key); if (el) cur[d.key] = d.type === 'check' ? el.checked : el.value; } };
    const advLabel = () => '高度な設定' + (advChanged() ? '（変更あり）' : '');
    const showTab = adv => {
      advTab = adv;
      for (const [id, on] of [['esTabBasic', !adv], ['esTabAdv', adv]]) { $(id).classList.toggle('on', on); $(id).setAttribute('aria-selected', on); }
      $('esBasic').hidden = adv; $('esAdv').hidden = !adv;
    };
    const render = () => {
      const missing = rows.filter(r => !r.entry && !r.refOnly).length;
      readForm();   // 描き直しても欄の値を残す
      cover(`<h2>実験用設定を保存する</h2>
      <p class="muted">参加者が実験中に使う画面の設定と、動画ごとの評価区間を決めます。保存したファイル（setup.json）と、Skills で作成した experiment.json を同じ実験用フォルダに入れてください。</p>
      ${old ? '<p class="muted">フォルダにある実験用設定の値を初めの値にしています（そこに無い項目は今の画面の値）。</p>' : ''}
      ${oldErr ? `<p class="expMiss">フォルダの setup.json を読めないので、今の画面の値を初めの値にしています（${esc(oldErr)}）。</p>` : ''}
      <div class="setTabs expTabs" role="tablist"><button id="esTabBasic" type="button" role="tab">基本</button><button id="esTabAdv" type="button" role="tab">${advLabel()}</button></div>
      <div id="esBasic" class="expTab"><div class="refTitle">設定</div>
      <div class="expForm">${E.SETTINGS.filter(d => !d.exp && !d.adv).map(ctl).join('')}</div>
      <div class="refTitle">実験中に出すボタン</div>
      <div class="expForm">${E.SETTINGS.filter(d => d.exp && !d.adv).map(ctl).join('')}</div></div>
      <div id="esAdv" class="expTab"><div class="expForm">${E.SETTINGS.filter(d => d.adv).map(ctl).join('')}</div></div>
      <div class="refTitle">動画ごとの評価区間（通常の画面で動画を開いて合わせたもの）</div>
      ${rows.length ? `<table class="expVids"><tr><th>動画</th><th>評価区間</th></tr>${rows.map(r => `<tr><td>${esc(r.path)}</td><td>${cell(r)}</td></tr>`).join('')}</table>` : '<p class="muted">動画がありません</p>'}
      ${nHidden ? `<p class="muted">下の階層の動画 ${nHidden} 本は表に出していません（experiment.json の試行にも setup.json にも無い動画）。実験で使うなら、フォルダ直下に置くか experiment.json の試行に書いてください。</p>` : ''}
      ${missing ? `<p class="expMiss">未設定の動画が ${missing} 本あります。実験で使う動画なら、通常の画面で開いて評価区間を合わせてから書き出し直してください（このまま書き出すと、その動画の試行は始められません）。</p>` : ''}
      <p class="muted">発声者が自分の録画を評価したときの区間区切りを、このフォルダにある同じ名前の録画に反映します。発声者の結果（試行の zip か _session.json）を選んでください。録画は先にこのフォルダに入れておいてください。</p>
      ${notes.map(m => `<p class="expMiss">${esc(m)}</p>`).join('')}
      <div class="expBtns"><button id="esSpk" type="button" title="発声者の結果（試行の zip か _session.json。複数可）を選ぶか、ここに落とす">発声者が設定した区間区切りを録画に反映する</button><button id="esSave" type="button">実験用設定を保存する</button><button id="esClose" type="button">閉じる</button></div>
      <input id="esSpkFile" type="file" accept=".zip,.json,application/zip,application/json" multiple hidden>`);
      $('esClose').addEventListener('click', () => cover(''));
      $('esTabBasic').addEventListener('click', () => showTab(false));
      $('esTabAdv').addEventListener('click', () => showTab(true));
      $('esAdv').addEventListener('change', () => { readForm(); $('esTabAdv').textContent = advLabel(); });
      showTab(advTab);
      $('esSpk').addEventListener('click', () => $('esSpkFile').click());
      $('esSpkFile').addEventListener('change', e => { const list = [...e.target.files]; e.target.value = ''; if (list.length) takeSpeaker(list); });
      dropTarget($('esSpk'), list => takeSpeaker(list.map(it => it.file || it)));
      $('esSave').addEventListener('click', () => {
        const settings = {};
        for (const d of E.SETTINGS) {
          const el = $('es_' + d.key);
          settings[d.key] = d.type === 'check' ? el.checked : d.type === 'number' || d.key === 'rate' ? +el.value : el.value;
        }
        const vids = Object.fromEntries(rows.filter(r => r.entry).map(r => [r.path, r.entry]));
        _.download('setup.json', JSON.stringify({ settings, videos: vids }, null, 2), 'application/json');
        $('status').textContent = '実験用設定（setup.json）を保存しました';
      });
    };
    // 発声者の結果を取り込む：録画のファイル名（同じ名前が 2 つ以上なら大きさも）でフォルダの動画を引き、評価区間を置き換える。
    // 基準音声の録画を選んでいて、それがフォルダにあれば refVideo にする（ref は同じ基準音声の動画のときだけ残す）。
    // 取り込んだ区間はブラウザにも覚え、通常の画面でその動画を開いたときと、書き出し直したときに同じ区間になる
    async function takeSpeaker(files) {
      notes = [];
      const vids = new Map(videos.map(v => [v.path, v]));
      for (const f of files) {
        let list;
        try { list = await _.readSpeaker(f); } catch (err) { notes.push('読めません：' + err.message); continue; }
        for (const sp of list) {
          const named = rows.filter(r => r.path.split('/').pop() === sp.video), row = named.length > 1 && sp.size ? named.find(r => vids.get(r.path).file.size === sp.size) || named[0] : named[0];
          const tag = [sp.pid, sp.trial ? `試行 ${sp.trial}` : ''].filter(Boolean).join(' ') || sp.src;
          if (!row) { notes.push(`${tag} の録画「${sp.video}」がフォルダにありません（録画をこのフォルダに入れてから取り込んでください）`); continue; }
          const vf = vids.get(row.path).file;
          if (sp.size && vf.size !== sp.size) notes.push(`${tag}：「${row.path}」の大きさが発声者の録画と違います（取り込みました。同じ録画かを確かめてください）`);
          const end = sp.range.edges ? sp.range.edges[sp.range.edges.length - 1] : sp.range.target;
          if (row.dur && end > row.dur + 0.02) { notes.push(`${tag}：評価区間の終了（${end} 秒）が「${row.path}」の長さを超えるので取り込みません`); continue; }
          const prev = row.entry || {}, refPath = sp.refVideo ? [...vids.keys()].find(p => p.split('/').pop() === sp.refVideo) : null;
          if (sp.refVideo && !refPath) notes.push(`${tag}：基準音声の録画「${sp.refVideo}」がフォルダに無いので、refVideo は付けません`);
          const ref = refPath ? { refVideo: refPath, ...(prev.refVideo === refPath && typeof prev.ref === 'number' ? { ref: prev.ref } : {}) }
            : { ...(typeof prev.refVideo === 'string' ? { refVideo: prev.refVideo } : {}), ...(typeof prev.ref === 'number' ? { ref: prev.ref } : {}) };
          row.entry = { ...videoEntry(sp.range, row.dur), ...ref, ...(Array.isArray(prev.novoice) ? { novoice: prev.novoice } : {}) };
          row.from = tag; row.kept = false;
          if (row.dur) _.storeRange(vf.name, `${vf.size}:${row.dur.toFixed(2)}`, sp.range);
          if (refPath) { const rr = rows.find(r => r.path === refPath); if (rr && !rr.entry) rr.refOnly = true; }
        }
      }
      render();
    }
    render();
  }

  // ---------- 操作の制限 ----------
  // 開始前・完了後はキーを効かせない（覆いの中の欄とボタンは除く）。視聴を許していなければ V も効かせない。
  // 他のキー操作（core/keys.js）より先に受け取るため、window の捕捉段階で止める
  window.addEventListener('keydown', e => {
    if (e.code === 'KeyE' && (e.ctrlKey || e.metaKey) && e.shiftKey) { if (X && X.state !== 'setup') { e.preventDefault(); exit(); } return; }
    const inCover = !$('expCover').hidden && $('expCover').contains(e.target);
    if (!X) { if (inCover) e.stopImmediatePropagation(); return; }   // setup.json の書き出しの画面の欄
    const block = () => { e.preventDefault(); e.stopImmediatePropagation(); };
    // 区間合わせの間は、再生（Space）・移動（←→）・1 フレーム移動（, .）だけを効かせる（取り消しなども止める）
    if (X.state === 'align') { if (!['Space', 'ArrowLeft', 'ArrowRight', 'Comma', 'Period'].includes(e.code) || e.altKey) block(); return; }
    // 覆いの中（「開始」ボタンなど）では既定の動作（Space・Enter で押す）だけを残し、再生などのツールの操作には渡さない
    if (X.state !== 'running') { if (inCover) e.stopImmediatePropagation(); else block(); return; }
    if (e.code === 'KeyV' && !X.set.review && !e.ctrlKey && !e.metaKey) block();
    if (e.code === 'KeyH' && !X.set.voicedBtn && !e.ctrlKey && !e.metaKey) block();   // 「発声」ボタンを出さない試行では H も効かない
  }, true);

  // ---------- フォルダを落として開く ----------
  // フォルダを選ぶ画面（webkitdirectory）は Windows ではファイルを出さないので、エクスプローラーから中身を確かめて落とせるようにする。
  // 落としたフォルダの中を下までたどり、{ file, path } の配列にする（path は「フォルダ名/…」で、webkitRelativePath と同じ形）
  async function entriesToFiles(entries) {
    const out = [];
    const walk = async en => {
      if (!en) return;
      if (en.isFile) { const file = await new Promise((ok, ng) => en.file(ok, ng)); out.push({ file, path: en.fullPath.replace(/^\//, '') }); return; }
      if (!en.isDirectory) return;
      const rd = en.createReader();
      for (;;) {   // readEntries は一度に全部を返さないことがあるので、空になるまで読む
        const part = await new Promise((ok, ng) => rd.readEntries(ok, ng));
        if (!part.length) break;
        for (const c of part) await walk(c);
      }
    };
    for (const en of entries) await walk(en);
    return out;
  }
  // ボタンにフォルダ（かファイル）を落とすと、選んだときと同じ処理に渡す
  function dropTarget(btn, fn) {
    const on = v => btn.classList.toggle('on', v);
    btn.addEventListener('dragover', e => { if (![...e.dataTransfer.types].includes('Files')) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; on(true); });
    btn.addEventListener('dragleave', () => on(false));
    btn.addEventListener('drop', async e => {
      e.preventDefault(); on(false);
      const items = [...e.dataTransfer.items].filter(it => it.kind === 'file');
      const entries = items.map(it => (it.webkitGetAsEntry ? it.webkitGetAsEntry() : null));
      const list = entries.every(Boolean) ? await entriesToFiles(entries) : [...e.dataTransfer.files];
      if (list.length) fn(list);
    });
  }

  async function openFolder(list) {
    const { cfgFile, setupFile, get } = readFolder(list);
    if (!cfgFile) { setup(null, get, { errors: ['選んだフォルダに experiment.json がありません'] }); return; }
    let exp = null, su = null;
    try { exp = await readJSON(cfgFile); } catch (err) { setup(null, get, { errors: ['experiment.json を JSON として読めません：' + err.message] }); return; }
    try { su = setupFile ? await readJSON(setupFile) : null; } catch (err) { setup(null, get, { errors: ['setup.json を JSON として読めません：' + err.message] }); return; }
    const res = E.check(exp, env(get), su);
    setup(res.errors.length ? exp : E.merge(exp, su), get, res);
  }
  $('expBtn').addEventListener('click', e => { e.currentTarget.blur(); $('expDir').click(); });
  $('expDir').addEventListener('change', e => { const list = [...e.target.files]; e.target.value = ''; if (list.length) openFolder(list); });
  $('expSetupBtn').addEventListener('click', e => { e.currentTarget.blur(); _.closePops(); $('expSetupDir').click(); });
  $('expSetupDir').addEventListener('change', e => { const list = [...e.target.files]; e.target.value = ''; if (list.length) setupExport(list); });
  dropTarget($('expBtn'), openFolder);
  dropTarget($('expSetupBtn'), list => { _.closePops(); setupExport(list); });
  $('expDoneBtn').addEventListener('click', e => { e.currentTarget.blur(); complete(); });
  $('expRecFile').addEventListener('change', e => { const f = e.target.files[0]; e.target.value = ''; if (f && X && X.state === 'pick') pickFile(f); });
  $('expRedoFile').addEventListener('change', e => { const f = e.target.files[0]; e.target.value = ''; if (f && X && X.state === 'setup' && X.redoPick) takeRedoFile(f); });
  $('expRefFile').addEventListener('change', e => { const f = e.target.files[0]; e.target.value = ''; if (f && X && X.state === 'align') setRef(f); });

  // 自動保存から再開してよいか：この実験・参加者・試行の保存データで、「開始」を押した後のもの（core/storage.js）。
  // やり直しの「開始」の前（前の回の task_start がログに残る）は再開せず、やり直しを当て直す
  const expResumable = s => {
    const m = s && s.meta && s.meta.experiment;
    return !!X && !!m && m.name === X.cfg.name && m.participant === X.pid && m.trial === X.i && phase(s.log || []) === 'running';
  };
  Object.assign(_, { expResumable, expOn: () => !!X, expBlocked: () => !!X && X.state !== 'running', expAligning: () => !!X && X.state === 'align', expState: () => (X ? X.state : null) });
})();
